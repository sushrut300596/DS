#include<stdio.h>
#include<stdlib.h>


/*
 * ************* Maximum Points: 10 ***************** 
 *
 * ********** PENALTY: -15 (negative 15) ************** 
 *  In following cases you will get penalty
 *  (a) Not submitted, 
 *  (b) Copied, 
 *  (c) Late submission
 *  (d) Submission is not as per the instructions
 *
 * ***************** Instructions *******************
 * (1) Implement ALL methods without any changes in input arguments. You are
 *     NOT allowed to add or remove any arguments of method.
 * (2) DO NOT CHANGE any names of structure, functions or arguments etc.
 * (3) You can add helper methods. Add comments to describe its purpose.
 * (4) You can make assumptions if something is not clear. Make sure you write 
 *     your assumptions wherever required as comments. If you make assumptions but 
 *     HAVE NOT mentioned then it may lead to loss of points.
 * (5) While submitting the code DO NOT KEEP any code in main method. Also DO 
 *     NOT CHANGE filename while submitting the code.
*/


/* README
   This implementation of integer sequence uses dynamic array.
   Here we have empty space before and after the sequence.
   We dont need to initiate a new array every time. We can use empty
   slots for new insertions. 
*/

typedef struct Item {
  int k;
}Item;

typedef struct DynamicArraySeq {
  Item *items; // Array of items
  int s;       // Start Index of sequence
  int e;       // End Index of sequence
  int size;    // Total size of Array
} DynamicArraySeq;

////////////////////////////////////////////////////


/// You can add helper methods here


////////////////////////////////////////////////////



// Read 'len' number of items and create DynamicArraySeq from it.
// Return address of the sequence.

DynamicArraySeq *build(int len) {
  //-----------------------------
  //        Implement me
  //-----------------------------
}

// Replace 'i'th item of the sequence with new item 'x'.
void set_at(int i, Item x, DynamicArraySeq *s) {
  //-----------------------------
  //        Implement me
  //-----------------------------
}

// Return i th item
Item get_at(int i, DynamicArraySeq s) {
  //-----------------------------
  //        Implement me
  //-----------------------------
}

// Return Length of sequence 
int length(DynamicArraySeq s) {
  //-----------------------------
  //        Implement me
  //-----------------------------
}

// insert 'x' at i th position in sequence s (REMEBER ith ITEM OF SEQUENCE NOT ARRAY).
void insert_at(int i, Item x, DynamicArraySeq *s) {
  //-----------------------------
  //        Implement me
  //-----------------------------
}

// removes the ith element of the sequence and returns deleted item.
// if empty part of array is bigger in size compare to sequence length then
// move sequence to smaller size array.
Item delete_at(int i, DynamicArraySeq *s) {
  //-----------------------------
  //        Implement me
  //-----------------------------
}

// insert item 'x' at the start of the sequence.
void insert_first(Item x, DynamicArraySeq *s) {
  //-----------------------------
  //        Implement me
  //-----------------------------
}
// insert item 'x' at the end of the sequence.
void insert_last(Item x, DynamicArraySeq *s) {
  //-----------------------------
  //        Implement me
  //-----------------------------
}

// delete first item of sequence and returns deleted item.
Item delete_first(DynamicArraySeq *s) {
  //-----------------------------
  //        Implement me
  //-----------------------------
}

// delete last item of sequence and returns deleted item.
Item delete_last(DynamicArraySeq *s) {
  //-----------------------------
  //        Implement me
  //-----------------------------
}

int main(void) {
}
