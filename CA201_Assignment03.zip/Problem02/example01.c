void f() {
  int a;
  int b;
  a = 10;
  b = a;
}

/*
  Expected Output:
  Valid.
*/
